@extends('layout.erp.app')
@section('title','result')


@section('page')
<div class="content-wrapper">

    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">

                <div class="row">
                    <div class="row d-flex align-items-baseline">
                        <div class="col-xl-9">
                            <img src="{{asset('img/logo-4.png')}}" width="80" alt="">
                        </div>
                        <div class="col-xl-3 float-end">
                            <!-- <a class="btn btn-light text-capitalize border-0" data-mdb-ripple-color="dark"><i class="fas fa-print text-primary"></i> Print</a>
                    <a class="btn btn-light text-capitalize" data-mdb-ripple-color="dark"><i class="far fa-file-pdf text-danger"></i> Export</a> -->
                        </div>
                        <hr>
                    </div>
                    <div class="col-md-12">
                        <div class="text-center">
                            <div style="font-size:20px;color:Teal;font-weight: bold;">MotherHood Public School</div>
                            <span style="color:Teal;font-weight: bold;"> Janatabug, Kadamtoli, Dhaka-1236</span>
                        </div>
                    </div>
                </div>
                <br><br>
                <form action="{{route('exams.store')}}" method="post">
                    @csrf
                    <div class="row">
                        <div class="col-xl-4">
                            <div class="col-xl-6">
                                Class's Name: <br>
                               
                                <div id="clas-info">

                                </div>
                            </div><br>

                            <div class="col-xl-6">
                                Subject's Name: <br>
                               
                                <div id="subject-info">

                                </div>
                            </div><br>


                        </div>
                        <div class="col-xl-4">
                            <div class="col-xl-6">
                                Section: <br>
                               
                                <div id="section-info">

                                </div>
                            </div><br>

                            <div class="col-xl-6">
                                Session: <br>
                              
                                <div id="session-info">

                                </div>
                            </div><br>


                        </div>
                        <div class="col-xl-4">
                            <div class="col-xl-6">
                                Department: <br>
                     
                                <div id="department-info">

                                </div>
                            </div><br>
							<div class="col-xl-6">
                                Exam Type: <br>

                                <div id="room-info">

                                </div>
                            </div><br>


                        </div>

                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>
                                        <h1>Results</h1>
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="form-check">
                                <td>exam_id</td>
                                <td>class</td>
                                <td>section</td>
                                <td>Student</td>
                                <td>marks</td>

                            @forelse ($results as $result)
                            <tr>

                                <td>{{$result->exam_id}}</td>
                                <td>{{$result->class}}</td>
                                <td>{{$result->section}}</td>
                                <td>{{$result->student}}</td>
                                <td>{{$result->obt_marks}}</td>
                                <td style="width: 200px;">
                                <div class="d-flex btn-group">
                                    <a class='btn btn-primary' href="{{route('results.edit',$result->id)}}">Edit<a>
                                    <a class='btn btn-info' href="{{route('results.show',$result->id)}}">Show<a>
                                    <form action="{{route('results.destroy',$result->id)}}" method="post" >	
                                        @csrf
                                        @method("DELETE")
                                        <input class='btn btn-danger' type="submit" name="btnDelete" class="btnDelete" data-id="{{$result->id}}"  value="Delete" />
                                    </form>
                                    </div>

                                </td>

                            
                          </tr>
                          @empty
                            <tr><td>No records</td></tr>

                            @endforelse

                            </tbody>
                            <tr>
                                <th>
                                    <input type="submit" name="btnSubmit" value="submit">
                                </th>
                            </tr>
                        </table>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    $(function() {

        $("#cmbClass").on("change", function() {

        })


        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $("#cmbExamType").on("change", function() {
            let section = $(this).val()
            let exam_type = $("#cmbExamType").val()
            let department = $("#cmbDepartment").val()
            let subject = $("#cmbSubject").val()
            let clas = $("#cmbClass").val()
            let section = $("#cmbSection").val()

            // alert(section+subject+clas)
            $.ajax({
                url: "http://localhost/ujjal/laravel/myapp1/public/index.php/api/myResult",
                type: "post",
                data: {
                    "exam_type": exam_type,
                    "department": department,
                    "section": section,
                    "subject": subject,
                    "clas": clas,
                },
                success: function(res) {
                    // console.log(res)
                    let data = JSON.parse(res)
                    console.log(data.results)
                    let html = ``;
                    data.results.forEach(ruselt => {
                      var html=`
                          <tr>
                            <td>${ruselt.id}</td>
                            <td>${ruselt.class_id}</td>
                            <td>${ruselt.obt_marks}</td>
                            
                          </tr>`;
                    });


                    $(".form-check").html(html)

                }
            })
        })

    })
</script>


@endsection